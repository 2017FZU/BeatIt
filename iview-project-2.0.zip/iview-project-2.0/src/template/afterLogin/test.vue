<template>
  <div class="container">
      <img src="/src/images/test.jpg" alt="">
  </div>
</template>

<script>
export default {
  data() {
    return {};
  }
  
};
</script>

<style>
.container {
  margin-left: -100px;
  margin-top: -10px;
  padding-left: 100px;
  height: 600px;
}
</style>

