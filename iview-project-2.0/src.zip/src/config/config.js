import Env from './env';

global.courseTitle = ''

let config = {
    env: Env
};
export default config;