import { port } from "_debugger";

//在线编辑图片功能，第三方插件，完全免费
var featherEditor = new Aviary.Feather({
  apiKey: '121285904@qq.com',//apikey可以免费申请，https://creativesdk.adobe.com/docs/web/#/index.html
  apiVersion: 1,
  theme: 'light', // Check out our new 'light' and 'dark' themes!
  tools: 'draw',//这里设置为all，可以显示所有的工具
  initTool: 'draw',//默认展开的工具
  language: 'zh_HANS',//简体中文
  appendTo: '',
  onSave: function (imageID, newURL) {
    //alert(newURL);
    $.ajax({
      // url: "ashx/CarInfo.ashx?type=DownloadCarPhoto&imgUrl=" + newURL + "&rand=" + Math.random(),
      url: newURL,
      success: function (url) {
        alert('保存成功');
        var img = document.getElementById(imageID);
        img.src = url;
      },
      error: function () {
        alert('error')
      }
    });

  },
  onError: function (errorObj) {
    alert(errorObj.message);
  }
});
function launchEditor(id, src) {
  featherEditor.launch({
    image: id,
    url: src
  });
  return false;
  export default function launchEditor() {

  }
}
